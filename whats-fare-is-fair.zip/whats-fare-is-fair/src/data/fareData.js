// Mock fare data for different providers between routes.
// In a production version this would come from a live pricing API.
export const providers = ['Ola', 'Uber', 'Rapido', 'InDrive'];

export const routes = [
  { id: 'r1', from: 'Bhubaneswar Airport', to: 'Master Canteen' },
  { id: 'r2', from: 'Patia', to: 'Railway Station' },
  { id: 'r3', from: 'Chandrasekharpur', to: 'Jaydev Vihar' },
  { id: 'r4', from: 'Khandagiri', to: 'Nandankanan' },
];

// Deterministic pseudo-fare generator so results are stable per route/provider
function seedFare(routeId, provider, base) {
  const seed = (routeId.charCodeAt(1) + provider.length) * 7;
  const variance = (seed % 40) - 15; // +/- variance
  return Math.max(60, base + variance);
}

export function getFaresForRoute(routeId) {
  const baseFares = { r1: 320, r2: 180, r3: 140, r4: 260 };
  const base = baseFares[routeId] || 150;

  return providers.map((provider) => ({
    provider,
    fare: seedFare(routeId, provider, base),
    eta: 4 + (provider.length % 6),
    surge: provider === 'Uber' && routeId === 'r1',
  }));
}
