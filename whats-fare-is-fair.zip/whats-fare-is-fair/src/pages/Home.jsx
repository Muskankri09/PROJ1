import { useState } from 'react';
import RouteSelector from '../components/RouteSelector.jsx';
import FareCard from '../components/FareCard.jsx';
import BookingModal from '../components/BookingModal.jsx';
import { getFaresForRoute } from '../data/fareData.js';

export default function Home() {
  const [fares, setFares] = useState([]);
  const [selectedFare, setSelectedFare] = useState(null);

  function handleCompare(routeId) {
    setFares(getFaresForRoute(routeId));
  }

  const cheapestFare =
    fares.length > 0 ? Math.min(...fares.map((f) => f.fare)) : null;

  return (
    <div className="home">
      <RouteSelector onCompare={handleCompare} />

      {fares.length > 0 && (
        <div className="fare-grid">
          {fares.map((fareInfo) => (
            <FareCard
              key={fareInfo.provider}
              fareInfo={fareInfo}
              isCheapest={fareInfo.fare === cheapestFare}
              onSelect={setSelectedFare}
            />
          ))}
        </div>
      )}

      <BookingModal fareInfo={selectedFare} onClose={() => setSelectedFare(null)} />
    </div>
  );
}
