export default function FareCard({ fareInfo, isCheapest, onSelect }) {
  const { provider, fare, eta, surge } = fareInfo;

  return (
    <div className={`fare-card ${isCheapest ? 'cheapest' : ''}`}>
      {isCheapest && <span className="badge">Best Price</span>}
      <h3>{provider}</h3>
      <p className="fare-amount">₹{fare}</p>
      <p className="eta">ETA: {eta} min</p>
      {surge && <p className="surge-warning">Surge pricing active</p>}
      <button onClick={() => onSelect(fareInfo)}>Select</button>
    </div>
  );
}
