import { useState } from 'react';

const TABS = ['Recent Trips', 'Saved Routes', 'Payment Methods'];

const mockTrips = [
  { id: 1, route: 'Patia → Railway Station', provider: 'Ola', fare: 165 },
  { id: 2, route: 'Khandagiri → Nandankanan', provider: 'Rapido', fare: 245 },
];

const mockSavedRoutes = [
  'Bhubaneswar Airport → Master Canteen',
  'Chandrasekharpur → Jaydev Vihar',
];

const mockPayments = ['UPI - Google Pay', 'Cash', 'Card ending 4521'];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState(TABS[0]);

  return (
    <div className="dashboard">
      <div className="tab-bar">
        {TABS.map((tab) => (
          <button
            key={tab}
            className={activeTab === tab ? 'active-tab' : ''}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="tab-content">
        {activeTab === 'Recent Trips' && (
          <ul>
            {mockTrips.map((trip) => (
              <li key={trip.id}>
                {trip.route} — {trip.provider} (₹{trip.fare})
              </li>
            ))}
          </ul>
        )}

        {activeTab === 'Saved Routes' && (
          <ul>
            {mockSavedRoutes.map((route, i) => (
              <li key={i}>{route}</li>
            ))}
          </ul>
        )}

        {activeTab === 'Payment Methods' && (
          <ul>
            {mockPayments.map((method, i) => (
              <li key={i}>{method}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
