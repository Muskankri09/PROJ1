import { useState } from 'react';

export default function BookingModal({ fareInfo, onClose }) {
  const [confirmed, setConfirmed] = useState(false);

  if (!fareInfo) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close">
          ×
        </button>
        {!confirmed ? (
          <>
            <h2>Confirm your ride</h2>
            <p>
              Provider: <strong>{fareInfo.provider}</strong>
            </p>
            <p>
              Fare: <strong>₹{fareInfo.fare}</strong>
            </p>
            <p>
              ETA: <strong>{fareInfo.eta} min</strong>
            </p>
            <button className="confirm-btn" onClick={() => setConfirmed(true)}>
              Confirm Booking
            </button>
          </>
        ) : (
          <>
            <h2>Booking Confirmed!</h2>
            <p>Your {fareInfo.provider} ride has been booked for ₹{fareInfo.fare}.</p>
            <button onClick={onClose}>Close</button>
          </>
        )}
      </div>
    </div>
  );
}
