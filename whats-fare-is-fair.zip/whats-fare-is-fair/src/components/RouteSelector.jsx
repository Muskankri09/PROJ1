import { useState } from 'react';
import { routes } from '../data/fareData.js';

export default function RouteSelector({ onCompare }) {
  const [selectedRoute, setSelectedRoute] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    if (!selectedRoute) {
      setError('Please select a route before comparing fares.');
      return;
    }
    setError('');
    onCompare(selectedRoute);
  }

  return (
    <form className="route-selector" onSubmit={handleSubmit}>
      <label htmlFor="route">Choose your route</label>
      <select
        id="route"
        value={selectedRoute}
        onChange={(e) => setSelectedRoute(e.target.value)}
      >
        <option value="">-- Select a route --</option>
        {routes.map((r) => (
          <option key={r.id} value={r.id}>
            {r.from} → {r.to}
          </option>
        ))}
      </select>
      {error && <p className="form-error">{error}</p>}
      <button type="submit">Compare Fares</button>
    </form>
  );
}
