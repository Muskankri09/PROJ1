import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Dashboard from './components/Dashboard.jsx';

export default function App() {
  return (
    <div className="app">
      <header className="navbar">
        <h1>What's Fare Is Fair</h1>
        <nav>
          <Link to="/">Compare Fares</Link>
          <Link to="/dashboard">Dashboard</Link>
        </nav>
      </header>

      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </main>

      <footer>
        <p>Built as a personal project to compare ride-hailing fares across providers.</p>
      </footer>
    </div>
  );
}
